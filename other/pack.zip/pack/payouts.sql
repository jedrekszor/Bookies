--------------------------------------------------------
--  File created - Thursday-April-23-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package PAYOUTS_CTRL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "AABD"."PAYOUTS_CTRL" AS 

procedure calculate_payout(p_odd_id odds.odd_id%type);
procedure recalculate_all_payouts;

END PAYOUTS_CTRL;

/
