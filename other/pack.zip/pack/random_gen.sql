--------------------------------------------------------
--  File created - Thursday-April-23-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package RANDOM_GENERATING
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "AABD"."RANDOM_GENERATING" is
  procedure events_teams_id;
end random_generating;

/
