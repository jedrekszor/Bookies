--------------------------------------------------------
--  File created - Thursday-April-23-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package CALCULATIONS_CTRL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "AABD"."CALCULATIONS_CTRL" AS 
      
  procedure calculate_probability_A;
  
  procedure calculate_stats;
  
  procedure calculate_probability_B;
      
END CALCULATIONS_CTRL;

/
