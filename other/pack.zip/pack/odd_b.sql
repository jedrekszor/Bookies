--------------------------------------------------------
--  File created - Thursday-April-23-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package Body ODD_CTRL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "AABD"."ODD_CTRL" AS

  procedure calculate_odd_A
  is
  cursor c_games is
    select * from games;
  begin
    delete from odds;
    for record in c_games
    loop
      calculate_odd_A_game(record.game_id, record.A_team_id, record.B_team_id);
    end loop;
  end calculate_odd_A;
  
  procedure calculate_odd_A_game(p_game_id number, p_A_team varchar2, p_B_team varchar2)
  is
  v_margin float := 0.3;
  v_max_odd float := 75;
  v_min_odd float := 1.01;
  
  v_id number := 1;
  v_A_win_id number := 1;
  v_draw_id number := 2;
  v_B_win_id number := 3;
  
  v_A_win float := 0;
  v_draw float := 0;
  v_B_win float := 0;
  cursor c_probability_A is
    select * from probability_A where (A_team_id = p_A_team and B_team_id = p_B_team) or (A_team_id = p_B_team and B_team_id = p_A_team);
  begin
    select coalesce(max(odd_id), 0)
    into v_id from odds;
    v_id := v_id + 1;

    for record in c_probability_A
    loop

      if record.A_win_chance = 0 then
        v_A_win := v_max_odd;
      else
        v_A_win := (1/(record.A_win_chance/100))*(1-v_margin);
      end if;
      
      if record.draw_chance = 0 then
        v_draw := v_max_odd;
      else
        v_draw := (1/(record.draw_chance/100))*(1-v_margin);
      end if;
      
      if record.B_win_chance = 0 then
        v_B_win := v_max_odd;
      else
        v_B_win := (1/(record.B_win_chance/100))*(1-v_margin);
      end if;
      
      if v_A_win <= 1 then
        v_A_win := v_min_odd;
      end if;
      
      if v_draw <= 1 then
        v_draw := v_min_odd;
      end if;
      
      if v_B_win <= 1 then
        v_B_win := v_min_odd;
      end if;
      
      insert into odds values (v_id, p_game_id, v_A_win_id, v_A_win, sysdate + 1/24);
      v_id := v_id + 1;

      insert into odds values (v_id, p_game_id, v_draw_id, v_draw, sysdate + 1/24);
      v_id := v_id + 1;

      insert into odds values (v_id, p_game_id, v_B_win_id, v_B_win, sysdate + 1/24);
      v_id := v_id + 1;
    end loop;
  end calculate_odd_A_game;
  
  procedure calculate_odd_B
  is
  cursor c_games is
    select * from games;
  begin
    delete from odds;
    for record in c_games
    loop
      calculate_odd_B_game(record.game_id, record.A_team_id, record.B_team_id);
    end loop;
  end calculate_odd_B;
  
  procedure calculate_odd_B_game(p_game_id number, p_A_team varchar2, p_B_team varchar2)
  is
  v_margin float := 0.3;
  v_max_odd float := 75;
  v_min_odd float := 1.01;
  
  v_id number := 1;
  v_A_win_id number := 1;
  v_draw_id number := 2;
  v_B_win_id number := 3;
  
  v_A_win float := 0;
  v_draw float := 0;
  v_B_win float := 0;
  cursor c_probability_B is
    select * from probability_B where (A_team_id = p_A_team and B_team_id = p_B_team) or (A_team_id = p_B_team and B_team_id = p_A_team);
  begin
    select coalesce(max(odd_id), 0)
    into v_id from odds;
    v_id := v_id + 1;

    for record in c_probability_B
    loop

      if record.A_win_chance = 0 then
        v_A_win := v_max_odd;
      else
        v_A_win := (1/(record.A_win_chance/100))*(1-v_margin);
      end if;
      
      if record.draw_chance = 0 then
        v_draw := v_max_odd;
      else
        v_draw := (1/(record.draw_chance/100))*(1-v_margin);
      end if;
      
      if record.B_win_chance = 0 then
        v_B_win := v_max_odd;
      else
        v_B_win := (1/(record.B_win_chance/100))*(1-v_margin);
      end if;
      
      if v_A_win <= 1 then
        v_A_win := v_min_odd;
      end if;
      
      if v_draw <= 1 then
        v_draw := v_min_odd;
      end if;
      
      if v_B_win <= 1 then
        v_B_win := v_min_odd;
      end if;
      
      insert into odds values (v_id, p_game_id, v_A_win_id, v_A_win, sysdate + 1/24);
      v_id := v_id + 1;

      insert into odds values (v_id, p_game_id, v_draw_id, v_draw, sysdate + 1/24);
      v_id := v_id + 1;

      insert into odds values (v_id, p_game_id, v_B_win_id, v_B_win, sysdate + 1/24);
      v_id := v_id + 1;
    end loop;
  end calculate_odd_B_game;
  
  procedure to_history_bets (p_phase_id phases.phase_id%type) is
  
      cursor c_odd_to_history is
      select o.odd_id as odd_id, 
             ga.game_id as game_id, 
             o.odd_type_id as odd_type_id, 
             o.value as value, 
             o.odd_date as odd_value
      from odds o
      join games ga on o.game_id = ga.game_id
      where ga.phase_id =  p_phase_id
      order by ga.phase_id;
  
    v_phase_id phases.phase_id%type;
    
  begin
    
    for curr_odd in c_odd_to_history loop
      
      insert into history_odds 
      values(curr_odd.odd_id, curr_odd.game_id, curr_odd.odd_type_id, curr_odd.value, curr_odd.odd_value);
      
      delete from odds
      where odd_id = curr_odd.odd_id;
      
    end loop;
  end;

END ODD_CTRL;

/
