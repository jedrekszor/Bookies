--------------------------------------------------------
--  File created - Thursday-April-23-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package HISTORY_COMPARISON_CTRL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "AABD"."HISTORY_COMPARISON_CTRL" AS 

  function check_match_result(
    P_A_TEAM_ID in varchar2,
    A_score in number,
    P_B_TEAM_ID in varchar2,
    B_score in number
    ) return varchar2; 
    
  procedure re_match_comparison_all; 

END HISTORY_COMPARISON_CTRL;

/
