--------------------------------------------------------
--  File created - Thursday-April-23-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package Body CALCULATIONS_CTRL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "AABD"."CALCULATIONS_CTRL" AS
  
  procedure calculate_probability_A is
  
    v_max number := 0;
    v_id number := 0;
    v_count number := 0;
    v_A_win_prob float := 0;
    v_draw_prob float := 0;
    v_B_win_prob float := 0;
    
  cursor c_history_comparison is
    select * from history_comparison;
    
  begin    
    for record in c_history_comparison   
    loop
    
      select COALESCE(max(prob_A_id), 0)
      into v_id
      from probability_A;
    
      select count(*)
      into v_count from probability_A
      where A_team_id = record.A_team_id and B_team_id = record.B_team_id;
      
      v_A_win_prob := (record.A_won/(record.matches_amount+1))*100;
      v_draw_prob := (record.draw/(record.matches_amount+1))*100;
      v_B_win_prob := (record.B_won/(record.matches_amount+1))*100;
      
      if v_count = 0 then
        insert into probability_A
        values (v_id, record.A_team_id, record.B_team_id, v_A_win_prob, v_draw_prob, v_B_win_prob);
      else
        update probability_A
        set A_win_chance = v_A_win_prob,
            draw_chance = v_draw_prob,
            B_win_chance = v_B_win_prob
        where A_team_id = record.A_team_id and B_team_id = record.B_team_id;
      end if;
      
      v_id := v_id + 1;
    end loop;
  end calculate_probability_A;
  
  procedure calculate_probability_B
  is
  v_count number := 0;
  v_A_win float := 0;
  v_A_draw float := 0;
  v_A_lose float := 0;
  v_B_win float := 0;
  v_B_draw float := 0;
  v_B_lose float := 0;
  
  v_final_A_win float := 0;
  v_final_draw float := 0;
  v_final_B_win float := 0;
  cursor c_probability_A is
    select * from probability_A;
  begin
    for record in c_probability_A
    loop
    select count(*)
    into v_count from probability_B
    where A_team_id = record.A_team_id and B_team_id = record.B_team_id;
    
    select (won/played)*100 into v_A_win from team_statistics where team_id = record.A_team_id;
    select (draw/played)*100 into v_A_draw from team_statistics where team_id = record.A_team_id;
    select (lost/played)*100 into v_A_lose from team_statistics where team_id = record.A_team_id;
    select (won/played)*100 into v_B_win from team_statistics where team_id = record.B_team_id;
    select (draw/played)*100 into v_B_draw from team_statistics where team_id = record.B_team_id;
    select (lost/played)*100 into v_B_lose from team_statistics where team_id = record.B_team_id;
    
    v_A_win := (v_A_win + record.A_win_chance)/2;
    v_A_draw := (v_A_draw + record.draw_chance)/2;
    v_A_lose := (v_A_lose + record.B_win_chance)/2;
    v_B_win := (v_B_win + record.B_win_chance)/2;
    v_B_draw := (v_B_draw + record.draw_chance)/2;
    v_B_lose := (v_B_lose + record.A_win_chance)/2;
    
    v_final_A_win := (v_A_win + v_B_lose)/2;
    v_final_draw := (v_A_draw + v_B_draw)/2;
    v_final_B_win := (v_B_win + v_A_lose)/2;
    
    if v_count = 0 then
--      insert
      insert into probability_B
      values(record.A_team_id, record.B_team_id, v_final_A_win, v_final_draw, v_final_B_win, record.prob_A_id);
    else
--      update
      update probability_B
      set A_win_chance = v_final_A_win,
          draw_chance = v_final_draw,
          B_win_chance = v_final_B_win
      where A_team_id = record.A_team_id and B_team_id = record.B_team_id;
    end if;
    end loop;
  end calculate_probability_B;
  
  procedure calculate_stats
  is
  v_team_A_id team_statistics.team_id%type;
  v_team_B_id team_statistics.team_id%type;
  v_competition_id team_statistics.competition_id%type;
  v_count number := 0;
  v_current_A_stats team_statistics%rowtype;
  v_current_B_stats team_statistics%rowtype;
  cursor c_history_games is
    select * from HISTORY_GAMES;
  begin
    for record in c_history_games
    loop
      select h.A_team_id, h.B_team_id, p.competition_id
      into v_team_A_id, v_team_B_id, v_competition_id from history_games h, phases p
      where h.phase_id = p.phase_id and h.game_id = record.game_id;
      
      select count(*)
      into v_count from team_statistics
      where team_id = v_team_A_id and competition_id = v_competition_id;
      
      if v_count = 0 then
        insert into team_statistics values(v_team_A_id, v_competition_id, 0, 0, 0, 0);
      end if;
      
      select count(*)
      into v_count from team_statistics
      where team_id = v_team_B_id and competition_id = v_competition_id;
      
      if v_count = 0 then
        insert into team_statistics values(v_team_B_id, v_competition_id, 0, 0, 0, 0);
      end if;
      
      select *
      into v_current_A_stats from team_statistics
      where team_id = v_team_A_id and competition_id = v_competition_id;
      
      select *
      into v_current_B_stats from team_statistics
      where team_id = v_team_B_id and competition_id = v_competition_id;
      
      if record.A_goals > record.B_goals then
        update team_statistics
        set played = v_current_A_stats.played + 1,
            won = v_current_A_stats.won + 1
        where team_id = v_team_A_id and competition_id = v_competition_id;
        update team_statistics
        set played = v_current_B_stats.played + 1,
            lost = v_current_B_stats.lost + 1
        where team_id = v_team_B_id and competition_id = v_competition_id;
        
      elsif record.A_goals < record.b_goals then
        update team_statistics
        set played = v_current_A_stats.played + 1,
            lost = v_current_A_stats.lost + 1
        where team_id = v_team_A_id and competition_id = v_competition_id;
        update team_statistics
        set played = v_current_B_stats.played + 1,
            won = v_current_B_stats.won + 1
        where team_id = v_team_B_id and competition_id = v_competition_id;
        
      elsif record.A_goals = record.b_goals then
        update team_statistics
        set played = v_current_A_stats.played + 1,
            draw = v_current_A_stats.draw + 1
        where team_id = v_team_A_id and competition_id = v_competition_id;
        
        update team_statistics
        set played = v_current_B_stats.played + 1,
            draw = v_current_B_stats.draw + 1
        where team_id = v_team_B_id and competition_id = v_competition_id;
      end if;
      
    end loop;
  end calculate_stats;
  
END CALCULATIONS_CTRL;

/
