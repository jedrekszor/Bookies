--------------------------------------------------------
--  File created - Thursday-April-23-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package ODD_CTRL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "AABD"."ODD_CTRL" AS 

  procedure calculate_odd_A;
  procedure calculate_odd_B;
  
  procedure calculate_odd_A_game(p_game_id number, p_A_team varchar2, p_B_team varchar2);
  procedure calculate_odd_B_game(p_game_id number, p_A_team varchar2, p_B_team varchar2);
  
  procedure to_history_bets(p_phase_id phases.phase_id%type);

END ODD_CTRL;

/
