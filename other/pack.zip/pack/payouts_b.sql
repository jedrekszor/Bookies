--------------------------------------------------------
--  File created - Thursday-April-23-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Package Body PAYOUTS_CTRL
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "AABD"."PAYOUTS_CTRL" AS

  procedure calculate_payout(p_odd_id odds.odd_id%type) is 
  
    v_id number := 0;
    v_final float := 0;
    cursor c_bets is
      select * from bets where odd_id = p_odd_id;
 
  begin 
    select coalesce(max(payout_id), 0)
    into v_id 
    from payouts;
    
    for record in c_bets
    loop
      v_id := v_id + 1;
      
      select o.value 
      into v_final 
      from odds o 
      where o.odd_id = record.odd_id;
      
      v_final := v_final * record.money_placed;
      insert into payouts values(v_id, v_final, sysdate + 1/24, record.client_id, record.bet_id);
      
    end loop;
  end calculate_payout;
  
  procedure recalculate_all_payouts is
  cursor c_history_odds is
    select *
    from history_odds;

  begin
    
    delete from payouts;
    
    for record in c_history_odds loop
      PAYOUTS_CTRL.CALCULATE_PAYOUT(record.odd_id);
    end loop;
  
  end;

END PAYOUTS_CTRL;

/
